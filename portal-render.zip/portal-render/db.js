'use strict';
// Supabase REST(PostgREST)를 fetch로 직접 호출 — supabase-js 없이 Node 18+ 에서 동작
module.exports = function makeDb(url, key) {
  const base = url.replace(/\/+$/, '') + '/rest/v1/kv_store';
  const headers = { apikey: key, 'Content-Type': 'application/json' };
  if (key.startsWith('eyJ')) headers.Authorization = 'Bearer ' + key;   // 예전 JWT 방식 키만 필요

  async function call(method, qs, body, extra) {
    const r = await fetch(base + qs, {
      method, headers: Object.assign({}, headers, extra || {}),
      body: body === undefined ? undefined : JSON.stringify(body)
    });
    if (!r.ok) throw new Error('Supabase ' + method + ' ' + r.status + ': ' + (await r.text()).slice(0, 300));
    return r;
  }
  const q = s => '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';

  return {
    async readAll() {
      const out = {};
      for (let from = 0; ; from += 1000) {
        const r = await call('GET', '?select=key,value&order=key', undefined,
          { 'Range-Unit': 'items', Range: from + '-' + (from + 999) });
        const rows = await r.json();
        rows.forEach(x => { out[x.key] = x.value; });
        if (rows.length < 1000) break;
      }
      return out;
    },
    async upsert(rows) {
      for (let i = 0; i < rows.length; i += 100)
        await call('POST', '?on_conflict=key', rows.slice(i, i + 100),
          { Prefer: 'resolution=merge-duplicates,return=minimal' });
    },
    async remove(keys) {
      for (let i = 0; i < keys.length; i += 50)
        await call('DELETE', '?key=in.(' + encodeURIComponent(keys.slice(i, i + 50).map(q).join(',')) + ')', undefined, { Prefer: 'return=minimal' });
    },
    async clear() { await call('DELETE', '?key=not.is.null', undefined, { Prefer: 'return=minimal' }); }
  };
};
