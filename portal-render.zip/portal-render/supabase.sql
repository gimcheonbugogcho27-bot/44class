-- Supabase > SQL Editor 에서 한 번만 실행하세요.
create table if not exists public.kv_store (
  key        text primary key,
  value      text not null,
  updated_at timestamptz not null default now()
);

-- 브라우저에서 Supabase로 직접 접근하지 못하게 막습니다.
-- (Render 서버가 service_role 키로만 읽고 씁니다. service_role 은 RLS 를 우회해요.)
alter table public.kv_store enable row level security;
