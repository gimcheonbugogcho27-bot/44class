'use strict';
const express = require('express');
const path = require('path');
const fs = require('fs');
const makeDb = require('./db');

const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error('SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY 환경변수가 필요해요.');
  process.exit(1);
}
const db = makeDb(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
const MAX_KEY = 200, MAX_VALUE = 4 * 1024 * 1024, MAX_OPS = 300;

const readAll = () => db.readAll();

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '25mb' }));

app.get('/api/kv', async (req, res) => {
  try { res.set('Cache-Control', 'no-store').json({ data: await readAll() }); }
  catch (e) { console.error(e); res.status(500).json({ error: 'read failed' }); }
});

// body: { clear?: true, set?: {key: value}, remove?: [key] }  (clear → set → remove 순서로 적용)
app.post('/api/kv', async (req, res) => {
  try {
    const { clear, set, remove } = req.body || {};
    const setKeys = set && typeof set === 'object' ? Object.keys(set) : [];
    const rmKeys = Array.isArray(remove) ? remove : [];
    if (setKeys.length + rmKeys.length > MAX_OPS) return res.status(400).json({ error: 'too many ops' });
    for (const k of setKeys) {
      if (!k || k.length > MAX_KEY || typeof set[k] !== 'string' || set[k].length > MAX_VALUE)
        return res.status(400).json({ error: 'invalid entry: ' + k.slice(0, 40) });
    }
    if (rmKeys.some(k => typeof k !== 'string' || !k || k.length > MAX_KEY)) return res.status(400).json({ error: 'invalid key' });

    if (clear === true) await db.clear();
    if (setKeys.length) {
      const now = new Date().toISOString();
      await db.upsert(setKeys.map(k => ({ key: k, value: set[k], updated_at: now })));
    }
    if (rmKeys.length) await db.remove(rmKeys);
    res.json({ ok: true });
  } catch (e) { console.error(e); res.status(500).json({ error: 'write failed' }); }
});

// index.html: 접속 시 저장된 데이터를 HTML 안에 미리 넣어 줘서, 앱이 동기식 localStorage처럼 바로 읽을 수 있어요.
const INDEX = fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf8');
const safeJson = o => JSON.stringify(o).replace(/</g, '\\u003c').split(String.fromCharCode(0x2028)).join('\\u2028').split(String.fromCharCode(0x2029)).join('\\u2029');
async function sendIndex(req, res) {
  let init = null;
  try { init = await readAll(); } catch (e) { console.error('초기 데이터 로드 실패:', e.message); }
  const tag = '<script>window.__KV_INIT=' + (init ? safeJson(init) : 'null') + ';</script>';
  res.set({ 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' })
     .send(INDEX.split('<!--KV_INIT-->').join(tag));
}
app.get(['/', '/index.html'], sendIndex);
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

app.listen(process.env.PORT || 3000, () => console.log('listening'));
