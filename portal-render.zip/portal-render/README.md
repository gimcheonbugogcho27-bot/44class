# 4-4반 포털 — Render + Supabase 저장

localStorage 대신 Supabase(DB)에 저장돼요. 브라우저 ⇄ Render 서버(`server.js`) ⇄ Supabase.
Supabase 키는 서버 환경변수에만 있고 브라우저에는 노출되지 않아요.

## 설정 순서
1. **Supabase**: 프로젝트 생성 → SQL Editor에서 `supabase.sql` 실행.
   Settings > API 에서 `Project URL`, `service_role` 키 복사.
2. **GitHub**: 이 폴더 전체를 저장소에 올리기 (`node_modules`, `.env` 제외).
3. **Render**: New > Web Service → 저장소 선택
   - Build: `npm install` / Start: `npm start`
   - Environment: `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`
4. 배포된 주소로 접속. (무료 플랜은 한동안 안 쓰면 첫 접속이 ~30초 느려요.)

## 기존 데이터 옮기기
기존 주소에서 ADMIN 로그인 → 컨트롤 화면의 **백업 추출** → 새 주소에서 **백업 불러오기**. 그대로 Supabase에 들어가요.

## 동작 방식
- `public/kv-shim.js`가 `localStorage`를 대체 (은행·자산·퀴즈 등 iframe 포함).
- 이 기기에만 남기는 값(DB에 안 올림): AI/검색 API 키, SNS 닉네임·기기ID, 테마, 알림 닫기 등 (`kv-shim.js`의 `LOCAL_RE`).
- 저장은 0.4초 모아서 전송, 실패 시 자동 재시도. 다른 기기 변경은 탭으로 돌아올 때 반영.
