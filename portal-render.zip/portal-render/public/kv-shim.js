/* localStorage → Render 서버 → Supabase 저장 shim
 * - 앱 코드는 그대로 localStorage.getItem/setItem 을 쓰고, 실제 저장은 /api/kv(Supabase)로 가요.
 * - 읽기는 메모리 캐시(서버가 HTML에 미리 넣어준 데이터)라서 동기식으로 바로 동작해요.
 * - API 키·개인 설정처럼 기기마다 달라야 하는 값은 이 브라우저의 진짜 localStorage에 그대로 둬요. */
(function () {
  'use strict';
  if (window.__kvShim) return;

  var REAL = null;
  try { REAL = window.localStorage; } catch (e) {}

  /* 이 기기에만 저장할 키 (DB에 올리지 않음) */
  var LOCAL_RE = new RegExp('^(' + [
    'class44_ai_.*',            // AI API 키·프록시·사용량
    'class44_portal_cse_.*',    // 구글 검색 API 키
    'class44_portal_usage', 'class44_portal_history', 'class44_portal_last_tab',
    'class44_neis_cfg', 'class44_api_loc',
    'class44_social_cid', 'class44_social_nick', 'class44_social_probe',
    'class44_mc_size', 'class44_bot_last',
    'classBankTheme', 'dismissedNotifications', 'bugok_hell_last',
    'kv_probe'
  ].join('|') + ')$');
  function isLocal(k) { return LOCAL_RE.test(k); }

  var data = Object.create(null);          // 공유(Supabase) 키 캐시
  var pending = fresh();
  var inflight = false, timer = null, failDelay = 0;

  function fresh() { return { clear: false, set: {}, remove: {} }; }
  function has(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }

  /* ---------- 초기 로드 ---------- */
  var init = window.__KV_INIT;
  if (!init) {                              // 서버가 넣어주지 않았다면 동기 요청으로 한 번 가져옴
    try {
      var x = new XMLHttpRequest();
      x.open('GET', '/api/kv', false); x.send();
      if (x.status === 200) init = JSON.parse(x.responseText).data;
    } catch (e) {}
  }
  var serverOk = !!init;
  if (init) Object.keys(init).forEach(function (k) { if (!isLocal(k)) data[k] = String(init[k]); });
  try { delete window.__KV_INIT; } catch (e) { window.__KV_INIT = undefined; }

  /* ---------- 서버로 저장 ---------- */
  function schedule(ms) { if (timer) clearTimeout(timer); timer = setTimeout(flush, ms == null ? 400 : ms); }
  function isEmpty(p) { return !p.clear && !Object.keys(p.set).length && !Object.keys(p.remove).length; }

  function flush(unloading) {
    if (timer) { clearTimeout(timer); timer = null; }
    if (inflight || isEmpty(pending)) return;
    var batch = pending; pending = fresh();
    var body = JSON.stringify({ clear: batch.clear, set: batch.set, remove: Object.keys(batch.remove) });
    inflight = true;
    fetch('/api/kv', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: body,
      keepalive: unloading === true && body.length < 60000
    }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      inflight = false; failDelay = 0; serverOk = true;
      if (!isEmpty(pending)) schedule(50);
    }).catch(function (e) {
      inflight = false;
      // 실패한 배치를 (더 새로운) pending 아래로 되돌려 놓고 다시 시도
      var p = pending, m = fresh();
      m.clear = batch.clear || p.clear;
      if (p.clear) { m.set = p.set; m.remove = p.remove; }
      else {
        Object.keys(batch.set).forEach(function (k) { if (!has(p.remove, k)) m.set[k] = batch.set[k]; });
        Object.keys(batch.remove).forEach(function (k) { if (!has(p.set, k)) m.remove[k] = 1; });
        Object.keys(p.set).forEach(function (k) { m.set[k] = p.set[k]; });
        Object.keys(p.remove).forEach(function (k) { m.remove[k] = 1; });
      }
      pending = m;
      failDelay = Math.min(30000, (failDelay || 1000) * 2);
      console.warn('[저장] 서버 저장 실패, ' + failDelay / 1000 + '초 후 재시도:', e && e.message);
      schedule(failDelay);
    });
  }
  window.addEventListener('pagehide', function () { flush(true); });
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'hidden') flush(true); else pull();
  });
  window.addEventListener('beforeunload', function () { flush(true); });

  /* ---------- 다른 기기에서 바뀐 내용 가져오기 (화면으로 돌아왔을 때) ---------- */
  var pulling = false;
  function pull() {
    if (pulling || inflight || !isEmpty(pending)) return;
    pulling = true;
    fetch('/api/kv', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (j) {
      pulling = false;
      if (!j || !j.data || inflight || !isEmpty(pending)) return;
      Object.keys(data).forEach(function (k) { if (!has(j.data, k)) delete data[k]; });
      Object.keys(j.data).forEach(function (k) { if (!isLocal(k)) data[k] = String(j.data[k]); });
    }).catch(function () { pulling = false; });
  }

  /* ---------- Storage 호환 객체 ---------- */
  function realLocalKeys() {
    var out = [];
    if (!REAL) return out;
    try { for (var i = 0; i < REAL.length; i++) { var k = REAL.key(i); if (isLocal(k)) out.push(k); } } catch (e) {}
    return out;
  }
  function allKeys() { return Object.keys(data).concat(realLocalKeys()); }

  var api = {
    getItem: function (k) {
      k = String(k);
      if (isLocal(k)) { try { return REAL ? REAL.getItem(k) : null; } catch (e) { return null; } }
      return has(data, k) ? data[k] : null;
    },
    setItem: function (k, v) {
      k = String(k); v = String(v);
      if (isLocal(k)) { if (REAL) REAL.setItem(k, v); return; }
      data[k] = v; pending.set[k] = v; delete pending.remove[k]; schedule();
    },
    removeItem: function (k) {
      k = String(k);
      if (isLocal(k)) { try { if (REAL) REAL.removeItem(k); } catch (e) {} return; }
      if (!has(data, k) && !has(pending.set, k)) return;
      delete data[k]; delete pending.set[k]; pending.remove[k] = 1; schedule();
    },
    clear: function () {
      Object.keys(data).forEach(function (k) { delete data[k]; });
      pending = fresh(); pending.clear = true; schedule();
      realLocalKeys().forEach(function (k) { try { REAL.removeItem(k); } catch (e) {} });
    },
    key: function (i) { var a = allKeys(); return i >= 0 && i < a.length ? a[i] : null; }
  };

  var store = new Proxy(api, {
    get: function (t, p) {
      if (p === 'length') return allKeys().length;
      if (typeof p === 'symbol') return undefined;
      if (has(api, p)) return api[p];
      var v = api.getItem(p); return v === null ? undefined : v;
    },
    set: function (t, p, v) { api.setItem(p, v); return true; },
    deleteProperty: function (t, p) { api.removeItem(p); return true; },
    has: function (t, p) { return has(api, p) || p === 'length' || api.getItem(p) !== null; },
    ownKeys: function () { return allKeys(); },
    getOwnPropertyDescriptor: function (t, p) {
      if (typeof p === 'string' && api.getItem(p) !== null)
        return { value: api.getItem(p), writable: true, enumerable: true, configurable: true };
      return undefined;
    }
  });

  function install(win) {
    try { Object.defineProperty(win, 'localStorage', { get: function () { return store; }, configurable: true }); } catch (e) {}
  }
  install(window);
  window.__kvShim = { store: store, flush: flush, pull: pull, ok: function () { return serverOk; } };

  /* ---------- srcdoc 로 만든 iframe(은행·자산·퀴즈·게임)에도 같은 저장소 연결 ---------- */
  var HOOK = '<script>try{var s=parent.__kvShim&&parent.__kvShim.store;if(s)Object.defineProperty(window,"localStorage",{get:function(){return s},configurable:true})}catch(e){}<\/script>';
  try {
    var d = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'srcdoc');
    if (d && d.set) {
      Object.defineProperty(HTMLIFrameElement.prototype, 'srcdoc', {
        configurable: true, enumerable: d.enumerable, get: d.get,
        set: function (html) {
          html = String(html);
          var m = /^\s*<!doctype[^>]*>/i.exec(html);        // doctype 앞에 넣으면 quirks 모드가 되니 뒤에 삽입
          html = m ? m[0] + HOOK + html.slice(m[0].length) : HOOK + html;
          d.set.call(this, html);
        }
      });
    }
  } catch (e) {}
})();
